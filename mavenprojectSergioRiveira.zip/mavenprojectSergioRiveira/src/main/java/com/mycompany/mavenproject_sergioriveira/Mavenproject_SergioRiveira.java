/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.mavenproject_sergioriveira;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.io.InputStream;
import java.util.Properties;
import java.io.BufferedWriter;
import java.nio.file.StandardOpenOption;

/**
 *
 * @author 2DAMV26
 */
public class Mavenproject_SergioRiveira {

    //Nombre de usuarioque ha iniciado sesión
    private static String usuarioActual = null;
    //Nombre completo del usuario
    private static String nombreActual = null;
    //Rol actual que inicializamos a invitado
    private static String perfilActual = "invitado";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        String nombre;
        String contrasenia;
        do {
            if (usuarioActual == null) {
                System.out.println("--- MENÚ INVITADO ---");
                System.out.println("1.-Para logearte");
                System.out.println("0.-EXIT");
            } else {
                mostrarMenuUsuario();
            }
            System.out.println("Introduzca una opción");
            String entradaOpcion = sc.nextLine().trim();
            try {
                opcion = Integer.parseInt(entradaOpcion);
            } catch (NumberFormatException e) {
                opcion = -1;
            }
            // Gestionamos las opciones para los usuarios autenticados
            if (usuarioActual != null) {
                switch (opcion) {

                    case 1:
                        if (perfilActual.equals("admin")|| perfilActual.equals("secretariado")) {
                            gestionarEmpleados(sc);
                        } else if (perfilActual.equals("enfermeria")) {
                            System.out.println("Gestión de alergias pendiente.");
                        } else {
                            System.out.println("Opción no disponible.");
                        }
                        break;
                    case 2:
                        if (perfilActual.equals("secretariado")|| perfilActual.equals("admin")) {
                            System.out.println("Gestión de citas pendiente.");
                        } else if (perfilActual.equals("enfermeria")) {
                            System.out.println("Gestión de tratamientos pendiente.");
                        }
                        break;
                    case 3:
                        if (perfilActual.equals("admin")) {
                            System.out.println("Gestión de alergias pendiente.");
                        } else {
                            System.out.println("Opción no válida para tu perfil.");
                        }
                        break;
                    case 4:
                        if (perfilActual.equals("admin")) {
                            System.out.println("Gestión de tratamientos pendiente.");
                        } else {
                            System.out.println("Opción no válida para tu perfil.");
                        }
                        break;
                    case 9:
                        cerrarSesion();
                        break;
                    case 0:
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
                continue;
            }

            switch (opcion) {
                case 1: {
                    //Comprobamos que no tenga sesión iniciada
                    if (usuarioActual != null) {
                        System.out.println("Ya hay una sesión iniciada. Cierra sesión primero.");
                        break;
                    }
                    //Pedimos datos al usuario para iniciar sesión
                    System.out.println("Introduzca el nombre de usuario.");
                    nombre = sc.nextLine().trim();
                    System.out.println("Introduzca la contraseña.");
                    contrasenia = sc.nextLine();
                    if (comprobarAdmin(nombre, contrasenia)) {
                        usuarioActual = nombre;
                        nombreActual = "Administrador General";
                        perfilActual = "admin";
                        System.out.println("Bienvenido, Administradot General");
                        System.out.println("Perfil: " + perfilActual);
                    } else {
                        boolean encontrado = false;
                        Path ruta = Path.of("credenciales.txt");
                        try (BufferedReader br = Files.newBufferedReader(ruta)) {
                            String linea;
                            while ((linea = br.readLine()) != null && !encontrado) {
                                String[] datos = linea.split("\\|");

                                if (datos.length == 4 && datos[0].equals(nombre) && datos[1].equals(contrasenia)) {
                                    encontrado = true;
                                    usuarioActual = datos[0];
                                    nombreActual = datos[2];
                                    perfilActual = datos[3].trim().toLowerCase();
                                    System.out.println("Bienvenido/a, " + nombreActual);
                                    System.out.println("Sesión iniciada como: " + perfilActual);
                                }
                            }
                            if (!encontrado) {
                                System.out.println("Usuario o contraseña incorrectos.");
                            }
                        } catch (IOException e) {
                            System.out.println("No se encuentra el fichero credenciales.txt");
                        }
                    }
                    break;
                }
                case 9: {
                    if (usuarioActual != null) {
                        cerrarSesion();
                    } else {
                        System.out.println("No hay ninguna sesión iniciada");
                    }
                    break;
                }
                case 0: {
                    System.out.println("Saliendo del sistema...");
                    System.out.println("Hasta pronto.");
                    break;
                }
                default: {
                    System.out.println("Introduzca una opción válida");
                    break;
                }
            }
        } while (opcion != 0);
    }

    //Metodo para comprobar si es admin o no
    private static boolean comprobarAdmin(String nombre, String contrasenia) {
        Properties propiedades = new Properties();
        try (InputStream entrada = Mavenproject_SergioRiveira.class.getResourceAsStream("/application.properties")) {
            if (entrada == null) {
                System.out.println(
                        "No se encuentra application.properties");
                return false;
            }
            propiedades.load(entrada);
            String usuario = propiedades.getProperty("admin.usuario");
            String password = propiedades.getProperty("admin.password");

            return usuario != null
                    && password != null
                    && usuario.equals(nombre)
                    && password.equals(contrasenia);

        } catch (IOException e) {
            System.out.println("Error al leer las propiedades del administrador.");
            return false;
        }
    }

    //Metodo para cerrar sesión
    private static void cerrarSesion() {
        usuarioActual = null;
        nombreActual = null;
        perfilActual = "invitado";
        System.out.println("Sesión cerrada correctamente.");
    }

    //Metodo para mostrar un menú de usuario
    private static void mostrarMenuUsuario() {
        System.out.println("--- MENÚ PRINCIPAL ---");
        System.out.println("Usuario: " + nombreActual);
        System.out.println("Perfil: " + perfilActual);

        switch (perfilActual.toLowerCase()) {

            case "secretariado": {
                System.out.println("1. Gestionar empleados");
                System.out.println("2. Gestionar citas");
                break;
            }
            case "enfermeria": {
                System.out.println("1. Gestionar alergias");
                System.out.println("2. Gestionar tratamientos");
                break;
            }
            case "admin": {
                System.out.println("1. Gestionar empleados");
                System.out.println("2. Gestionar citas");
                System.out.println("3. Gestionar alergias");
                System.out.println("4. Gestionar tratamientos");
                break;
            }
        }
        //Cambiamos el case 2 a 9 para que no haya problemas con los case 2 de Gestionar
        System.out.println("9. Cerrar sesión");
        System.out.println("0. Salir");
    }

    //Metodo para gestionar empleados 
    private static void gestionarEmpleados(Scanner sc) {
        int opcion;

        do {
            System.out.println("--- GESTIÓN DE EMPLEADOS ---");
            System.out.println("1. Registrar empleado");
            System.out.println("0. Volver al menú principal");
            System.out.print("Selecciona una opción: ");
            String entrada = sc.nextLine().trim();

            try {
                opcion = Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                opcion = -1;
            }

            switch (opcion) {
                case 1: {
                    registrarEmpleado(sc);
                    break;
                }
                case 0: {
                    System.out.println("Volviendo al menú principal...");
                    break;
                }
                default: {
                    System.out.println("Opción no válida.");
                }
            }
        } while (opcion != 0);
    }

    //Metodo para registrar empleado
    private static void registrarEmpleado(Scanner sc) {
        System.out.println("\n--- REGISTRO DE EMPLEADO ---");
        //Seleccionar tipo de empleado
        System.out.println("Tipo de empleado:");
        System.out.println("1. Secretariado");
        System.out.println("2. Enfermeria");
        System.out.println("3. Cirujano");
        System.out.print("Selecciona una opcion: ");
        String tipo = sc.nextLine().trim();
        String perfil;
        switch (tipo) {
            case "1":
                perfil = "secretariado";
                break;
            case "2":
                perfil = "enfermeria";
                break;
            case "3":
                perfil = "cirujano";
                break;
            default:
                System.out.println("Tipo de empleado no valido.");
                return;
        }
        //Datos personales
        System.out.print("Nombre: ");
        String nombre = sc.nextLine().trim();
        System.out.print("Apellidos: ");
        String apellidos = sc.nextLine().trim();
        System.out.print("Telefono: ");
        String telefono = sc.nextLine().trim();
        System.out.print("Email: ");
        String email = sc.nextLine().trim();
        System.out.print("NIF/NIE: ");
        String nif = sc.nextLine().trim();
        System.out.print("Direccion: ");
        String direccion = sc.nextLine().trim();
        //Datos del puesto
        String datoPuesto = "";

        if (perfil.equals("secretariado")) {
            System.out.print("Anios de experiencia: ");
            datoPuesto = sc.nextLine().trim();
            try {
                if (Integer.parseInt(datoPuesto) < 0) {
                    System.out.println("Los anios no pueden ser negativos.");
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("Debes introducir un numero valido.");
                return;
            }
        } else if (perfil.equals("enfermeria")) {
            System.out.print("Categoria (A, B o C): ");
            datoPuesto = sc.nextLine().trim().toUpperCase();
            if (!datoPuesto.matches("[ABC]")) {
                System.out.println("La categoria debe ser A, B o C.");
                return;
            }
        } else {
            System.out.println("Un cirujano debe tener una o varias especialidades.");
            System.out.print("Especialidades: ");
            datoPuesto = sc.nextLine().trim();
            if (datoPuesto.isEmpty()) {
                System.out.println("Debes introducir al menos una especialidad.");
                return;
            }
        }
        //Validarmos los datos comunes
        if (nombre.isEmpty() || apellidos.isEmpty() || telefono.isEmpty() || email.isEmpty() || nif.isEmpty() || direccion.isEmpty()) {
            System.out.println("Todos los datos personales son obligatorios.");
            return;
        }
        if (nombre.contains("|") || apellidos.contains("|")) {
            System.out.println("Los datos no pueden contener el caracter |.");
            return;
        }
        if (!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            System.out.println("El email no tiene un formato valido.");
            return;
        }
        if (!telefono.matches("[+]?[0-9 ]{9,15}")) {
            System.out.println("El telefono no tiene un formato valido.");
            return;
        }
        if (nif.contains("|") || nif.contains(" ")) {
            System.out.println("El NIF/NIE no puede contener espacios ni |.");
            return;
        }
        //Pedimos las credenciales
        System.out.print("Nombre de usuario: ");
        String usuario = sc.nextLine().trim();
        System.out.print("Contrasenia: ");
        String password = sc.nextLine();
        if (usuario.isEmpty() || password.isEmpty() || usuario.matches(".*\\s+.*") || password.matches(".*\\s+.*") || usuario.contains("|") || password.contains("|")) {
            System.out.println("El usuario y la contrasenia deben ser validos, sin espacios ni |.");
            return;
        }
        //Comprobamos que el usuario no exista
        Path ruta = Path.of("credenciales.txt");
        try {
            if (Files.exists(ruta)) {
                try (BufferedReader br = Files.newBufferedReader(ruta)) {
                    String linea;
                    while ((linea = br.readLine()) != null) {
                        String[] datos = linea.split("\\|", -1);
                        if (datos.length == 4 && datos[0].equals(usuario)) {
                            System.out.println("Nombre de usuario ya registrado.");
                            return;
                        }
                    }
                }
            }

            //Confirmar el registro
            System.out.println("--- RESUMEN DEL REGISTRO ---");
            System.out.println("Nombre: " + nombre + " " + apellidos);
            System.out.println("Perfil: " + perfil);
            System.out.println("Usuario: " + usuario);
            System.out.println("Dato especifico: " + datoPuesto);

            System.out.print("¿Confirmas el registro? (S/N): ");
            String confirmacion = sc.nextLine().trim();
            if (!confirmacion.equalsIgnoreCase("S")) {
                System.out.println("Registro cancelado.");
                return;
            }
            //Guardamos las credenciales
            try (BufferedWriter bw = Files.newBufferedWriter(
                    ruta,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND)) {
                bw.write(usuario + "|" + password + "|" + nombre + " " + apellidos + "|" + perfil);
                bw.newLine();
            }
            System.out.println("Empleado registrado correctamente.");
        } catch (IOException e) {
            System.out.println("Error al consultar o actualizar credenciales.txt: " + e.getMessage());
        }
    }
}
