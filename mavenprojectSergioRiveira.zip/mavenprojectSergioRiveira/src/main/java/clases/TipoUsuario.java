/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV26
 */
public enum TipoUsuario {
    INVITADO,SECRETARIADO,ENFERMERIA,ADMIN;
}
