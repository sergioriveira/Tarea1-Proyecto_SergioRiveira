/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV26
 */
public class Enfermeria extends Empleado{
    private Long id_enfermeria;
    private CategoriaEnfermeria categoria;
    //Constructor
    public Enfermeria(Long id_enfermeria, CategoriaEnfermeria categoria, Long id, String nombre, String apellidos, int telefono, String email, String NIF, String direccion) {
        super(id, nombre, apellidos, telefono, email, NIF, direccion);
        this.id_enfermeria = id_enfermeria;
        this.categoria = categoria;
    }
    //Getter y Setter
    public Long getId_enfermeria() {
        return id_enfermeria;
    }

    public void setId_enfermeria(Long id_enfermeria) {
        this.id_enfermeria = id_enfermeria;
    }

    public CategoriaEnfermeria getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaEnfermeria categoria) {
        this.categoria = categoria;
    }
    
}
