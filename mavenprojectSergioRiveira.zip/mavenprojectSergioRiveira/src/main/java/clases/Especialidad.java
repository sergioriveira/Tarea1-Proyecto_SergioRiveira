/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV26
 */
public class Especialidad extends Cirujano{
    private Long id_especialidad;
    private String nombre_especialidad;
    //Constructor
    public Especialidad(Long id_especialidad, String nombre_especialidad, Long id, String nombre, String apellidos, int telefono, String email, String NIF, String direccion) {
        super(id, nombre, apellidos, telefono, email, NIF, direccion);
        this.id_especialidad = id_especialidad;
        this.nombre_especialidad = nombre_especialidad;
    }
    //Getter y Setter
    public Long getId_especialidad() {
        return id_especialidad;
    }

    public void setId_especialidad(Long id_especialidad) {
        this.id_especialidad = id_especialidad;
    }

    public String getNombre_especialidad() {
        return nombre_especialidad;
    }

    public void setNombre_especialidad(String nombre_especialidad) {
        this.nombre_especialidad = nombre_especialidad;
    }
}
