/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.Set;

/**
 *
 * @author 2DAMV26
 */
public class Historial {
    private Long id_historial;
    private Long num_historial;
    private String descripcion;
    
    private Set <HistorialAlergia> historialAlergias;
    //Constructor
    public Historial(Long id_historial, Long num_historial, String descripcion) {
        this.id_historial = id_historial;
        this.num_historial = num_historial;
        this.descripcion = descripcion;
    }
    //Getter y Setter
    public Long getId_historial() {
        return id_historial;
    }

    public void setId_historial(Long id_historial) {
        this.id_historial = id_historial;
    }

    public Long getNum_historial() {
        return num_historial;
    }

    public void setNum_historial(Long num_historial) {
        this.num_historial = num_historial;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Set<HistorialAlergia> getHistorialAlergias() {
        return historialAlergias;
    }

    public void setHistorialAlergias(Set<HistorialAlergia> historialAlergias) {
        this.historialAlergias = historialAlergias;
    }
    
}
