/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV26
 */
public class Secretariado extends Empleado{
    private Long id_secretariado;
    private int numAnios;
    //Constructor
    public Secretariado(Long id_secretariado, int numAnios, Long id, String nombre, String apellidos, int telefono, String email, String NIF, String direccion) {
        super(id, nombre, apellidos, telefono, email, NIF, direccion);
        this.id_secretariado = id_secretariado;
        this.numAnios = numAnios;
    }
     
    //Getter y Setter    
    public int getNumAnios() {
        return numAnios;
    }

    public void setNumAnios(int numAnios) {
        this.numAnios = numAnios;
    }
    
    public Long getId_secretariado() {
        return id_secretariado;
    }

    public void setId_secretariado(Long id_secretariado) {
        this.id_secretariado = id_secretariado;
    }
}
