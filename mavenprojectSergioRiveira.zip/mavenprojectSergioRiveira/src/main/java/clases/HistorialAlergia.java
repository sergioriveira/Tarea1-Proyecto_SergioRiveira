/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV26
 */
public class HistorialAlergia {
    private Long id_historialAlergia;
    
    private Historial historial;
    private Alergia alergia;
    //Constructor
    public HistorialAlergia(Long id_historialAlergia, Historial historial, Alergia alergia) {
        this.id_historialAlergia = id_historialAlergia;
        this.historial = historial;
        this.alergia = alergia;
    }
    //Getter y Setter
    public Long getId_historialAlergia() {
        return id_historialAlergia;
    }

    public void setId_historialAlergia(Long id_historialAlergia) {
        this.id_historialAlergia = id_historialAlergia;
    }

    public Historial getHistorial() {
        return historial;
    }

    public void setHistorial(Historial historial) {
        this.historial = historial;
    }

    public Alergia getAlergia() {
        return alergia;
    }

    public void setAlergia(Alergia alergia) {
        this.alergia = alergia;
    }
    
}
