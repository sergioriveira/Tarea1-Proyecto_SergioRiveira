/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.Set;

/**
 *
 * @author 2DAMV26
 */
public class Alergia {
    private Long id_alergia;
    private String nombre;
    
    private Medicamento medicamento;
    
    private Set<HistorialAlergia> historialAlergias;
    //Constructor
    public Alergia(Long id_alergia, String nombre, Medicamento medicamento) {
        //creo q así hacemos q el id de la alergia es el mismo q el de medicamento, así la alergia 1 tiene el mismo id q el medicamento 1
        //this.id_alergia = medicamento.getId_medicamento(); 
        this.id_alergia = id_alergia;
        this.nombre = nombre;
        this.medicamento = medicamento;
    }
    //Getter y Setter
    public Long getId_alergia() {
        return id_alergia;
    }

    public void setId_alergia(Long id_alergia) {
        this.id_alergia = id_alergia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(Medicamento medicamento) {
        this.medicamento = medicamento;
    }

    public Set<HistorialAlergia> getHistorialAlergias() {
        return historialAlergias;
    }

    public void setHistorialAlergias(Set<HistorialAlergia> historialAlergias) {
        this.historialAlergias = historialAlergias;
    }
    
}
