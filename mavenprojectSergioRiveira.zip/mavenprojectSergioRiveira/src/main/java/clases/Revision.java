/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.time.LocalDateTime;

/**
 *
 * @author 2DAMV26
 */
public class Revision extends Cita{
    private Long id_revision;
    //Constructor
    public Revision(Long id_revision, Long id_cita, LocalDateTime fecha_hora, String anotaciones, Tratamiento tratamiento) {
        super(id_cita, fecha_hora, anotaciones, tratamiento);
        this.id_revision = id_revision;
    }
    
    //Getter y Setter
    public Long getId_revision() {
        return id_revision;
    }

    public void setId_revision(Long id_revision) {
        this.id_revision = id_revision;
    }
}
