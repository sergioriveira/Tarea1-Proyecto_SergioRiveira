/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author 2DAMV26
 */
public class Sesion {
    private String nombre;
    private String nombre_usuario;
    private TipoUsuario tipo_usuario;
    //Constructor
    public Sesion(String nombre, String nombre_usuario, TipoUsuario tipo_usuario) {
        this.nombre = nombre;
        this.nombre_usuario = nombre_usuario;
        this.tipo_usuario = tipo_usuario;
    }
    //Getter y Setter
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public TipoUsuario getTipo_usuario() {
        return tipo_usuario;
    }

    public void setTipo_usuario(TipoUsuario tipo_usuario) {
        this.tipo_usuario = tipo_usuario;
    }
}
