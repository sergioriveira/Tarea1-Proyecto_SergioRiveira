/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.time.LocalDateTime;

/**
 *
 * @author 2DAMV26
 */
public class Cita {
    protected Long id_cita;
    protected LocalDateTime fecha_hora;
    protected String anotaciones;
    
    private Tratamiento tratamiento;
    //Constructor
    public Cita(Long id_cita, LocalDateTime fecha_hora, String anotaciones, Tratamiento tratamiento) {
        this.id_cita = id_cita;
        this.fecha_hora = fecha_hora;
        this.anotaciones = anotaciones;
        this.tratamiento = tratamiento;
    }
    //Getter y Setter
    public Long getId_cita() {
        return id_cita;
    }

    public void setId_cita(Long id_cita) {
        this.id_cita = id_cita;
    }

    public LocalDateTime getFecha_hora() {
        return fecha_hora;
    }

    public void setFecha_hora(LocalDateTime fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public String getAnotaciones() {
        return anotaciones;
    }

    public void setAnotaciones(String anotaciones) {
        this.anotaciones = anotaciones;
    }

    public Tratamiento getTratamiento() {
        return tratamiento;
    }

    public void setTratamiento(Tratamiento tratamiento) {
        this.tratamiento = tratamiento;
    }
}
