/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.List;

/**
 *
 * @author 2DAMV26
 */
public class Cirujano extends Empleado{
    private List<Especialidad> especialidades;
    //Constructor
    public Cirujano(Long id, String nombre, String apellidos, String telefono, String email, String NIF, String direccion) {
        super(id, nombre, apellidos, telefono, email, NIF, direccion);
    }
    
    public List<Especialidad> getEspecialidades() { return especialidades; }
    public void setEspecialidades(List<Especialidad> e) { this.especialidades = e; }
}
