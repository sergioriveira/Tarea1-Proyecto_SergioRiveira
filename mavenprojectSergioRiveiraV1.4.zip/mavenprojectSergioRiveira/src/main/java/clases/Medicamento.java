/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.io.Serializable;

/**
 *
 * @author 2DAMV26
 */
public class Medicamento implements Serializable{
    //Esta linea sirve para que si hay cambios en Alergia o Medicamento no se genera un número distinto en el .dat
    private static final long serialVersionUID = 1L;
    
    private Long id_medicamento;
    private String nombre;
    private String principio;
    private int dosisMaxima;
    //Constructor
    public Medicamento(Long id_medicamento, String nombre, String principio, int dosisMaxima) {
        this.id_medicamento = id_medicamento;
        this.nombre = nombre;
        this.principio = principio;
        this.dosisMaxima = dosisMaxima;
    }
    //Getter y Setter
    public Long getId_medicamento() {
        return id_medicamento;
    }

    public void setId_medicamento(Long id_medicamento) {
        this.id_medicamento = id_medicamento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPrincipio() {
        return principio;
    }

    public void setPrincipio(String principio) {
        this.principio = principio;
    }

    public int getDosisMaxima() {
        return dosisMaxima;
    }

    public void setDosisMaxima(int dosisMaxima) {
        this.dosisMaxima = dosisMaxima;
    }
    
}
