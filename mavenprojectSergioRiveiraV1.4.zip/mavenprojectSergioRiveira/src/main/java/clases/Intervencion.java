/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author 2DAMV26
 */
public class Intervencion extends Cita {

    private Long id_intervencion;
    private int duracion;
    private Enfermeria enfermeria;
    private List<Cirujano> cirujanos;

    //Constructor
    public Intervencion(Long id_intervencion, int duracion, Long id_cita, LocalDateTime fecha_hora, String anotaciones, Tratamiento tratamiento) {
        super(id_cita, fecha_hora, anotaciones, tratamiento);
        this.id_intervencion = id_intervencion;
        this.duracion = duracion;
    }

    //Getter y Setter
    public Long getId_intervencion() {
        return id_intervencion;
    }

    public void setId_intervencion(Long id_intervencion) {
        this.id_intervencion = id_intervencion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public Enfermeria getEnfermeria() {
        return enfermeria;
    }

    public void setEnfermeria(Enfermeria enfermeria) {
        this.enfermeria = enfermeria;
    }

    public List<Cirujano> getCirujanos() {
        return cirujanos;
    }

    public void setCirujanos(List<Cirujano> cirujanos) {
        this.cirujanos = cirujanos;
    }
}
