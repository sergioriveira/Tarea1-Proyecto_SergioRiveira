/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject_sergioriveira;

import clases.Alergia;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AlergiaRepositorio {

    private static final Path CARPETA = Path.of("alergias");

    private static Path rutaDe(long id) {
        return CARPETA.resolve("alergia_" + id + ".dat");
    }

    // Leemos todos los ficheros, los ordenamos por id y avisa de los corruptos
    public static List<Alergia> listarTodas() {
        List<Alergia> lista = new ArrayList<>();
        if (!Files.isDirectory(CARPETA)) {
            return lista;
        }
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(CARPETA, "alergia_*.dat")) {
            for (Path p : ds) {
                try (ObjectInputStream ois = new ObjectInputStream(
                        new BufferedInputStream(Files.newInputStream(p)))) {
                    lista.add((Alergia) ois.readObject());
                } catch (IOException | ClassNotFoundException | ClassCastException e) {
                    System.out.println("Aviso: no se pudo leer " + p.getFileName() + ", se omite.");
                }
            }
        } catch (IOException e) {
            System.out.println("Error al acceder a la carpeta de alergias: " + e.getMessage());
        }
        lista.sort(Comparator.comparing(Alergia::getId_alergia));
        return lista;
    }

    // Máximo id existente (según los nombres de fichero) + 1; si no hay ninguno, 1
    public static long siguienteId() {
        long max = 0;
        if (!Files.isDirectory(CARPETA)) {
            return 1;
        }
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(CARPETA, "alergia_*.dat")) {
            for (Path p : ds) {
                String nombre = p.getFileName().toString();
                String num = nombre.substring("alergia_".length(), nombre.length() - ".dat".length());
                try {
                    max = Math.max(max, Long.parseLong(num));
                } catch (NumberFormatException e) {
                    // fichero con nombre raro: se ignora
                }
            }
        } catch (IOException e) {
            System.out.println("Error al calcular el identificador: " + e.getMessage());
        }
        return max + 1;
    }

    // Crea el fichero o lo sobrescribe si ya existe
    public static void guardar(Alergia a) throws IOException {
        Files.createDirectories(CARPETA);
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new BufferedOutputStream(Files.newOutputStream(rutaDe(a.getId_alergia()))))) {
            oos.writeObject(a);
        }
    }

    // Devuelve la alergia con ese id, o null si no existe
    public static Alergia buscarPorId(long id) {
        for (Alergia a : listarTodas()) {
            if (a.getId_alergia() == id) {
                return a;
            }
        }
        return null;
    }
}
