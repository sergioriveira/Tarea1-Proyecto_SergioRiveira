/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.mavenproject_sergioriveira;

import clases.Alergia;
import clases.Medicamento;
import java.util.ArrayList;
import java.util.List;
import clases.Sesion;
import clases.TipoUsuario;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.io.InputStream;
import java.util.Properties;
import java.io.BufferedWriter;
import java.nio.file.StandardOpenOption;

/**
 *
 * @author 2DAMV26
 */
public class Mavenproject_SergioRiveira {

    // Sesión actual=null significa perfil Invitado
    private static Sesion sesionActual = null;

    private static final String[] ESPECIALIDADES = {
        "Odontología", "Fisioterapia", "Ginecología", "Cirugía plástica",
        "Digestivo", "Cirugía pediátrica", "Radiología", "Geriatría"
    };

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            if (sesionActual == null) {
                mostrarMenuInvitado();
            } else {
                mostrarMenuUsuario();
            }
            opcion = leerOpcion(sc);

            if (sesionActual == null) {
                gestionarOpcionInvitado(opcion, sc);
            } else {
                gestionarOpcionUsuario(opcion, sc);
            }
        } while (opcion != 0);
        System.out.println("Saliendo del sistema... Hasta pronto.");
    }

    //Metodo para leer la opcion
    private static int leerOpcion(Scanner sc) {
        System.out.print("Introduzca una opción: ");
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    //Metodo para mostrar el menu de invitado
    private static void mostrarMenuInvitado() {
        System.out.println("\n--- MENÚ INVITADO ---");
        System.out.println("1. Iniciar sesión");
        System.out.println("0. Salir");
    }

    //Metodo para mostrar el menu de usuario
    private static void mostrarMenuUsuario() {
        System.out.println("\n--- MENÚ PRINCIPAL ---");
        System.out.println("Usuario: " + sesionActual.getNombre());
        System.out.println("Perfil: " + sesionActual.getTipo_usuario());
        switch (sesionActual.getTipo_usuario()) {
            case SECRETARIADO:
                System.out.println("1. Gestionar empleados");
                break;
            case ENFERMERIA:
                System.out.println("1. Gestionar alergias y medicamentos");
                break;
            case ADMIN:
                System.out.println("1. Gestionar empleados");
                System.out.println("2. Gestionar alergias y medicamentos");
                break;
            default:
                break;
        }
        System.out.println("9. Cerrar sesión");
        System.out.println("0. Salir");
    }

    //Metodo para gestionar la opcion de invitado
    private static void gestionarOpcionInvitado(int opcion, Scanner sc) {
        switch (opcion) {
            case 1:
                login(sc);
                break;
            case 0:
                break;
            default:
                System.out.println("Opción no válida.");
        }
    }

    //Metodo para gestionar la opcion de usuario
    private static void gestionarOpcionUsuario(int opcion, Scanner sc) {
        TipoUsuario tipo = sesionActual.getTipo_usuario();
        switch (opcion) {
            case 1:
                if (tipo == TipoUsuario.SECRETARIADO || tipo == TipoUsuario.ADMIN) {
                    gestionarEmpleados(sc);
                } else if (tipo == TipoUsuario.ENFERMERIA) {
                    gestionarAlergias(sc);
                }
                break;
            case 2:
                if (tipo == TipoUsuario.ADMIN) {
                    gestionarAlergias(sc);
                } else {
                    System.out.println("Opción no válida.");
                }
                break;
            case 9:
                cerrarSesion();
                break;
            case 0:
                break;
            default:
                System.out.println("Opción no válida.");
        }
    }

    //Metodo de login
    private static void login(Scanner sc) {
        System.out.print("Nombre de usuario: ");
        String usuario = sc.nextLine().trim();
        System.out.print("Contraseña: ");
        String password = sc.nextLine();

        if (usuario.isEmpty() || password.isEmpty()) {
            System.out.println("El usuario y la contraseña no pueden estar vacíos.");
            return;
        }

        if (comprobarAdmin(usuario, password)) {
            sesionActual = new Sesion("Administrador General", usuario, TipoUsuario.ADMIN);
            System.out.println("Bienvenido, Administrador General.");
            return;
        }

        Path ruta = Path.of("credenciales.txt");
        try (BufferedReader br = Files.newBufferedReader(ruta)) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split("\\|", -1);
                if (datos.length == 4 && datos[0].equals(usuario) && datos[1].equals(password)) {
                    TipoUsuario tipo = convertirPerfil(datos[3].trim());
                    if (tipo == null) {
                        System.out.println("Tu perfil (" + datos[3].trim() + ") no tiene acceso al sistema.");
                        return;
                    }
                    sesionActual = new Sesion(datos[2], datos[0], tipo);
                    System.out.println("Bienvenido/a, " + datos[2] + ".");
                    return;
                }
            }
            System.out.println("Usuario o contraseña incorrectos.");
        } catch (IOException e) {
            System.out.println("No se puede leer el fichero credenciales.txt");
        }
    }

    //Metodo para convertir la sesion
    private static TipoUsuario convertirPerfil(String perfil) {
        switch (perfil.toLowerCase()) {
            case "secretariado":
                return TipoUsuario.SECRETARIADO;
            case "enfermeria":
                return TipoUsuario.ENFERMERIA;
            default:
                return null;
        }
    }

    //Metodo para cerrarSesion
    private static void cerrarSesion() {
        sesionActual = null;
        System.out.println("Sesión cerrada correctamente. Ahora eres Invitado.");
    }

    //Metodo para comprobar si es admin o no
    private static boolean comprobarAdmin(String nombre, String contrasenia) {
        Properties propiedades = new Properties();
        try (InputStream entrada = Mavenproject_SergioRiveira.class.getResourceAsStream("/application.properties")) {
            if (entrada == null) {
                System.out.println(
                        "No se encuentra application.properties");
                return false;
            }
            propiedades.load(entrada);
            String usuario = propiedades.getProperty("admin.usuario");
            String password = propiedades.getProperty("admin.password");

            return usuario != null
                    && password != null
                    && usuario.equals(nombre)
                    && password.equals(contrasenia);

        } catch (IOException e) {
            System.out.println("Error al leer las propiedades del administrador.");
            return false;
        }
    }

    //Metodo para obpeter el usuario admin
    private static String obtenerUsuarioAdmin() {
        Properties props = new Properties();
        try (InputStream is = Mavenproject_SergioRiveira.class
                .getResourceAsStream("/application.properties")) {
            if (is != null) {
                props.load(is);
                String u = props.getProperty("admin.usuario");
                if (u != null) {
                    return u;
                }
            }
        } catch (IOException e) {
            // se usa el valor por defecto
        }
        return "admin";
    }

    //Metodo para gestionar empleados 
    private static void gestionarEmpleados(Scanner sc) {
        int opcion;

        do {
            System.out.println("--- GESTIÓN DE EMPLEADOS ---");
            System.out.println("1. Registrar empleado");
            System.out.println("0. Volver al menú principal");
            System.out.print("Selecciona una opción: ");
            String entrada = sc.nextLine().trim();

            try {
                opcion = Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                opcion = -1;
            }

            switch (opcion) {
                case 1: {
                    registrarEmpleado(sc);
                    break;
                }
                case 0: {
                    System.out.println("Volviendo al menú principal...");
                    break;
                }
                default: {
                    System.out.println("Opción no válida.");
                }
            }
        } while (opcion != 0);
    }

    //Metodo para registrar empleado
    private static void registrarEmpleado(Scanner sc) {
        System.out.println("--- REGISTRO DE EMPLEADO ---");
        //Seleccionar tipo de empleado
        System.out.println("Tipo de empleado:");
        System.out.println("1. Secretariado");
        System.out.println("2. Enfermeria");
        System.out.println("3. Cirujano");
        System.out.print("Selecciona una opcion: ");
        String tipo = sc.nextLine().trim();
        String perfil;
        switch (tipo) {
            case "1":
                perfil = "secretariado";
                break;
            case "2":
                perfil = "enfermeria";
                break;
            case "3":
                perfil = "cirujano";
                break;
            default:
                System.out.println("Tipo de empleado no valido.");
                return;
        }
        //Datos personales
        System.out.print("Nombre: ");
        String nombre = sc.nextLine().trim();
        System.out.print("Apellidos: ");
        String apellidos = sc.nextLine().trim();
        System.out.print("Telefono: ");
        String telefono = sc.nextLine().trim();
        System.out.print("Email: ");
        String email = sc.nextLine().trim();
        System.out.print("NIF/NIE: ");
        String nif = sc.nextLine().trim();
        System.out.print("Direccion: ");
        String direccion = sc.nextLine().trim();
        //Datos del puesto
        String datoPuesto = "";
        if (perfil.equals("secretariado")) {
            System.out.print("Anios de experiencia: ");
            datoPuesto = sc.nextLine().trim();
            try {
                if (Integer.parseInt(datoPuesto) < 0) {
                    System.out.println("Los anios no pueden ser negativos.");
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("Debes introducir un numero valido.");
                return;
            }
        } else if (perfil.equals("enfermeria")) {
            System.out.print("Categoria (A, B o C): ");
            datoPuesto = sc.nextLine().trim().toUpperCase();
            if (!datoPuesto.matches("[ABC]")) {
                System.out.println("La categoria debe ser A, B o C.");
                return;
            }
        } else {
            System.out.println("Un cirujano debe tener entre 1 y 3 especialidades.");
            datoPuesto = String.join(", ", pedirEspecialidades(sc));
        }
        //Validarmos los datos comunes
        if (nombre.isEmpty() || apellidos.isEmpty() || telefono.isEmpty() || email.isEmpty() || nif.isEmpty() || direccion.isEmpty()) {
            System.out.println("Todos los datos personales son obligatorios.");
            return;
        }
        if (nombre.contains("|") || apellidos.contains("|")) {
            System.out.println("Los datos no pueden contener el caracter |.");
            return;
        }
        if (!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            System.out.println("El email no tiene un formato valido.");
            return;
        }
        if (!telefono.matches("[+]?[0-9 ]{9,15}")) {
            System.out.println("El telefono no tiene un formato valido.");
            return;
        }
        if (nif.contains("|") || nif.contains(" ")) {
            System.out.println("El NIF/NIE no puede contener espacios ni |.");
            return;
        }
        //Pedimos las credenciales
        System.out.print("Nombre de usuario: ");
        String usuario = sc.nextLine().trim();
        System.out.print("Contrasenia: ");
        String password = sc.nextLine();
        if (usuario.isEmpty() || password.isEmpty() || usuario.matches(".*\\s+.*") || password.matches(".*\\s+.*") || usuario.contains("|") || password.contains("|")) {
            System.out.println("El usuario y la contrasenia deben ser validos, sin espacios ni |.");
            return;
        }
        if (usuario.equalsIgnoreCase(obtenerUsuarioAdmin())) {
            System.out.println("Ese nombre de usuario está reservado.");
            return;
        }
        //Comprobamos que el usuario no exista
        Path ruta = Path.of("credenciales.txt");
        try {
            if (Files.exists(ruta)) {
                try (BufferedReader br = Files.newBufferedReader(ruta)) {
                    String linea;
                    while ((linea = br.readLine()) != null) {
                        String[] datos = linea.split("\\|", -1);
                        if (datos.length == 4 && datos[0].equals(usuario)) {
                            System.out.println("Nombre de usuario ya registrado.");
                            return;
                        }
                    }
                }
            }

            //Confirmar el registro
            System.out.println("--- RESUMEN DEL REGISTRO ---");
            System.out.println("Nombre: " + nombre + " " + apellidos);
            System.out.println("Perfil: " + perfil);
            System.out.println("Usuario: " + usuario);
            System.out.println("Dato especifico: " + datoPuesto);

            System.out.print("¿Confirmas el registro? (S/N): ");
            String confirmacion = sc.nextLine().trim();
            if (!confirmacion.equalsIgnoreCase("S")) {
                System.out.println("Registro cancelado.");
                return;
            }
            //calculamos ai el fichero ya acaba en salto de línea
            boolean necesitaSalto = false;
            if (Files.exists(ruta) && Files.size(ruta) > 0) {
                byte[] contenido = Files.readAllBytes(ruta);
                necesitaSalto = contenido[contenido.length - 1] != '\n';
            }
            //Guardamos las credenciales
            try (BufferedWriter bw = Files.newBufferedWriter(
                    ruta,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND)) {
                if (necesitaSalto) {
                    bw.newLine();
                }
                bw.write(usuario + "|" + password + "|" + nombre + " " + apellidos + "|" + perfil);
                bw.newLine();
            }
            System.out.println("Empleado registrado correctamente.");
        } catch (IOException e) {
            System.out.println("Error al consultar o actualizar credenciales.txt: " + e.getMessage());
        }
    }
    //Metodo para pedir la especialidad

    private static List<String> pedirEspecialidades(Scanner sc) {
        System.out.println("Especialidades disponibles:");
        for (int i = 0; i < ESPECIALIDADES.length; i++) {
            System.out.println((i + 1) + ". " + ESPECIALIDADES[i]);
        }
        while (true) {
            System.out.print("Elige de 1 a 3 números separados por comas: ");
            String[] partes = sc.nextLine().trim().split(",");
            List<String> elegidas = new ArrayList<>();
            boolean valido = partes.length >= 1 && partes.length <= 3;
            for (String p : partes) {
                if (!valido) {
                    break;
                }
                try {
                    int n = Integer.parseInt(p.trim());
                    if (n < 1 || n > ESPECIALIDADES.length
                            || elegidas.contains(ESPECIALIDADES[n - 1])) {
                        valido = false;
                    } else {
                        elegidas.add(ESPECIALIDADES[n - 1]);
                    }
                } catch (NumberFormatException e) {
                    valido = false;
                }
            }
            if (valido) {
                return elegidas;
            }
            System.out.println("Selección no válida (sin repetidos, números del 1 al 8, máximo 3).");
        }
    }

    //Submenú de alergias
    //Metodo para gestionar las alergias
    private static void gestionarAlergias(Scanner sc) {
        int opcion;
        do {
            System.out.println("\n--- GESTIÓN DE ALERGIAS Y MEDICAMENTOS ---");
            System.out.println("1. Ver alergias");
            System.out.println("2. Nueva alergia");
            System.out.println("3. Editar alergia");
            System.out.println("0. Volver al menú principal");
            opcion = leerOpcion(sc);
            switch (opcion) {
                case 1:
                    verAlergias();
                    break;
                case 2:
                    nuevaAlergia(sc);
                    break;
                case 3:
                    editarAlergia(sc);
                    break;
                case 0:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    //Caso de uso 3A
    private static void verAlergias() {
        List<Alergia> alergias = AlergiaRepositorio.listarTodas();
        if (alergias.isEmpty()) {
            System.out.println("No hay alergias registradas.");
            return;
        }
        System.out.println("\n--- LISTADO DE ALERGIAS ---");
        for (Alergia a : alergias) {
            Medicamento m = a.getMedicamento();
            System.out.println("ID: " + a.getId_alergia());
            System.out.println("  Alergia: " + a.getNombre());
            System.out.println("  Medicamento: " + m.getNombre());
            System.out.println("  Principio activo: " + m.getPrincipio());
            System.out.println("  Dosis máxima diaria: " + m.getDosisMaxima() + " mg");
            System.out.println("-----------------------------");
        }
    }

    //Pide un texto que no puede estar vacío
    private static String pedirTexto(Scanner sc, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            if (!texto.isEmpty()) {
                return texto;
            }
            System.out.println("El campo no puede estar vacío.");
        }
    }

    //Pide un entero mayor que 0
    private static int pedirDosis(Scanner sc, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                int dosis = Integer.parseInt(sc.nextLine().trim());
                if (dosis > 0) {
                    return dosis;
                }
            } catch (NumberFormatException e) {
                // se repite la petición
            }
            System.out.println("La dosis debe ser un número entero mayor que 0.");
        }
    }

    //Caso de uso 3B
    private static void nuevaAlergia(Scanner sc) {
        System.out.println("\n--- NUEVA ALERGIA ---");
        String nombreAlergia = pedirTexto(sc, "Nombre de la alergia: ");
        String nombreMed = pedirTexto(sc, "Nombre del medicamento: ");
        String principio = pedirTexto(sc, "Principio activo: ");
        int dosis = pedirDosis(sc, "Dosis máxima diaria (mg): ");

        long id = AlergiaRepositorio.siguienteId();

        System.out.println("\n--- RESUMEN ---");
        System.out.println("ID: " + id);
        System.out.println("Alergia: " + nombreAlergia);
        System.out.println("Medicamento: " + nombreMed);
        System.out.println("Principio activo: " + principio);
        System.out.println("Dosis máxima diaria: " + dosis + " mg");
        System.out.print("¿Confirmas el alta? (S/N): ");
        if (!sc.nextLine().trim().equalsIgnoreCase("S")) {
            System.out.println("Alta cancelada.");
            return;
        }

        Medicamento med = new Medicamento(id, nombreMed, principio, dosis);
        Alergia alergia = new Alergia(id, nombreAlergia, med);
        try {
            AlergiaRepositorio.guardar(alergia);
            System.out.println("Alergia registrada correctamente (ID " + id + ").");
        } catch (IOException e) {
            System.out.println("Error al guardar la alergia: " + e.getMessage());
        }
    }

    //Caso de uso 3C
    //Metodo para editar una alergia
    private static void editarAlergia(Scanner sc) {
        List<Alergia> alergias = AlergiaRepositorio.listarTodas();
        if (alergias.isEmpty()) {
            System.out.println("No hay alergias registradas para editar.");
            return;
        }
        verAlergias();

        //Pedir y validar el id
        System.out.print("ID de la alergia a editar (Enter para cancelar): ");
        String entrada = sc.nextLine().trim();
        if (entrada.isEmpty()) {
            System.out.println("Edición cancelada.");
            return;
        }
        long id;
        try {
            id = Long.parseLong(entrada);
        } catch (NumberFormatException e) {
            System.out.println("El ID debe ser un número.");
            return;
        }
        Alergia alergia = AlergiaRepositorio.buscarPorId(id);
        if (alergia == null) {
            System.out.println("No existe ninguna alergia con ID " + id + ".");
            return;
        }
        Medicamento med = alergia.getMedicamento();

        //Pedir los nuevos valores (si el usuario pulsa "Enter" se mantiene el actual)
        System.out.println("\nEditando alergia ID " + id + " (Enter para mantener el valor actual)");
        System.out.print("Alergia [" + alergia.getNombre() + "]: ");
        String nuevoNombre = sc.nextLine().trim();
        if (nuevoNombre.isEmpty()) {
            nuevoNombre = alergia.getNombre();
        }
        System.out.print("Medicamento [" + med.getNombre() + "]: ");
        String nuevoMed = sc.nextLine().trim();
        if (nuevoMed.isEmpty()) {
            nuevoMed = med.getNombre();
        }
        System.out.print("Principio activo [" + med.getPrincipio() + "]: ");
        String nuevoPrincipio = sc.nextLine().trim();
        if (nuevoPrincipio.isEmpty()) {
            nuevoPrincipio = med.getPrincipio();
        }
        int nuevaDosis = med.getDosisMaxima();
        while (true) {
            System.out.print("Dosis máxima diaria en mg [" + med.getDosisMaxima() + "]: ");
            String dosisTxt = sc.nextLine().trim();
            if (dosisTxt.isEmpty()) {
                break;
            }
            try {
                int d = Integer.parseInt(dosisTxt);
                if (d > 0) {
                    nuevaDosis = d;
                    break;
                }
            } catch (NumberFormatException e) {
                // repetimos la petición
            }
            System.out.println("La dosis debe ser un número entero mayor que 0.");
        }

        //Resumen y confirmación
        System.out.println("\n--- CAMBIOS ---");
        System.out.println("Alergia: " + alergia.getNombre() + " -> " + nuevoNombre);
        System.out.println("Medicamento: " + med.getNombre() + " -> " + nuevoMed);
        System.out.println("Principio activo: " + med.getPrincipio() + " -> " + nuevoPrincipio);
        System.out.println("Dosis máxima: " + med.getDosisMaxima() + " mg -> " + nuevaDosis + " mg");
        System.out.print("¿Confirmas los cambios? (S/N): ");
        if (!sc.nextLine().trim().equalsIgnoreCase("S")) {
            System.out.println("Edición cancelada. No se ha modificado nada.");
            return;
        }

        //Aplicamos los cambios y sobrescribimos el fichero
        alergia.setNombre(nuevoNombre);
        med.setNombre(nuevoMed);
        med.setPrincipio(nuevoPrincipio);
        med.setDosisMaxima(nuevaDosis);
        try {
            AlergiaRepositorio.guardar(alergia);
            System.out.println("Alergia actualizada correctamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar los cambios: " + e.getMessage());
        }
    }
}
